package pacakage1;

public class C extends A{


	public void method1c() {
	
		System.out.println("the is  public:" +p);
		System.out.println("the is  protected:" +z);
		System.out.println("the is  default:" +y);
	}
}
